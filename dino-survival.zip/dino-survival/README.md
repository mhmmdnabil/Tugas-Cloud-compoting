# 🦕 Dino Survival

Game multiplayer 1vs1 seperti Dino Chrome, berbasis WebSocket — bisa main bareng teman secara realtime.

## ✨ Fitur

- Daftar & Login (akun tersimpan di server)
- Pilih 1vs1 di antara 3 room (Lava Canyon, Ice Tundra, Neon Desert)
- Pilih peran: **Pemain** (max 2 orang) atau **Penonton**
- Layar split atas-bawah (Pemain 1 di atas, Pemain 2 di bawah)
- Sistem 3 ronde (best of 3)
- Kecepatan game progresif — makin lama main, makin cepat & makin menantang
- Leaderboard (nama, win rate, poin)
- Poin: menang 1 ronde = +2 poin, kalah = -1 poin
- Penonton bisa chat realtime + emote
- Voice chat realtime untuk penonton (bisa nyala/mati)
- Pemain hanya bisa melihat & mendengar chat/voice penonton (tidak bisa balas)

## 🚀 Cara Menjalankan

### 1. Install Node.js
Download di https://nodejs.org (pilih versi LTS) jika belum punya.

### 2. Install dependency
Buka terminal di folder ini, lalu jalankan:
```bash
npm install
```

### 3. Jalankan server
```bash
npm start
```
atau
```bash
node server.js
```

Server akan berjalan di:
```
http://localhost:3000
```

### 4. Main bareng teman (1 jaringan WiFi)

Cek IP lokal komputer kamu:
- Windows: `ipconfig` → lihat **IPv4 Address**
- Mac/Linux: `ifconfig` atau `ip a`

Teman buka di browser (harus 1 WiFi yang sama):
```
http://IP-KAMU:3000
```
Contoh: `http://192.168.1.11:3000`

### 5. Main dari jaringan berbeda (lewat internet)
Pakai ngrok untuk membuat link publik:
```bash
npx ngrok http 3000
```

> ⚠️ Voice chat (WebRTC) butuh koneksi HTTPS jika diakses dari domain publik selain `localhost`. Ngrok otomatis menyediakan HTTPS, jadi aman dipakai.

## 🎮 Cara Bermain

| Aksi | Kontrol |
|---|---|
| Lompat | `Spasi` atau `↑` |
| Jongkok | Tahan `↓` |
| HP/Mobile | Tap di area canvas dino kamu |

1. Daftar akun → login
2. Pilih menu **MAIN** → pilih salah satu room
3. Pilih peran: **Pemain** atau **Penonton**
4. Kalau slot pemain sudah penuh (2 orang), kamu otomatis diarahkan ke mode penonton
5. Game otomatis mulai begitu 2 pemain siap (hitungan mundur 3-2-1)
6. Menang 2 dari 3 ronde = juara match

## 📁 Struktur Folder

```
dino-survival/
├── server.js       → Backend WebSocket + REST API + logika game
├── index.html      → Frontend (UI, canvas game, chat, voice chat)
├── package.json    → Daftar dependency
└── README.md       → Dokumen ini
```

## ⚠️ Catatan

Data user, leaderboard, dan statistik **tersimpan di memori server (RAM)** — akan hilang jika server di-restart. Untuk penyimpanan permanen, perlu ditambahkan database (SQLite/MongoDB/dll).
