

# 🦖 DINO SURVIVAL MULTIPLAYER
### Final Project - Game Online Real-Time Berbasis WebSocket

---

## 📖 Deskripsi Proyek

**Dino Survival Multiplayer** adalah game online berbasis web yang dikembangkan sebagai Final Project mata kuliah **Pemrograman WebSocket**.

Game ini memungkinkan dua pemain bermain secara **real-time** dalam satu room menggunakan teknologi **WebSocket**. Pemain harus menghindari berbagai rintangan (obstacle) dengan melakukan **jump** atau **duck** agar dapat bertahan hidup selama mungkin. Seluruh proses permainan seperti sinkronisasi pemain, perhitungan skor, serta penyimpanan hasil pertandingan dilakukan oleh server.

Selain gameplay multiplayer, sistem juga menyediakan leaderboard dan dashboard statistik pemain berdasarkan data yang tersimpan pada database MySQL.

---

# 👨‍💻 Mata Kuliah

**Pemrograman WebSocket**

Program Studi Teknik Informatika

Universitas Islam Kalimantan Muhammad Arsyad Al Banjari

---

# 👥 Anggota Kelompok

| Nama | NPM | Peran |
|------|-----|--------|
| Muhammad Nabil | 2410010233 | Frontend & Game Developer |
| Muhammad Febrian | 2410010172 | Backend & WebSocket Developer |
| Muhammad Khalil | 2410010632 | Database & Data Analyst |

---

# 🎯 Tujuan Project

Project ini dibuat untuk memenuhi tugas **Final Project Mata Kuliah Pemrograman WebSocket** dengan tujuan:

- Mengimplementasikan komunikasi real-time menggunakan WebSocket.
- Membuat game multiplayer berbasis web.
- Mengembangkan sistem room untuk minimal dua pemain.
- Menyimpan data hasil permainan ke database.
- Menampilkan dashboard statistik pemain.
- Melakukan analisis performa berdasarkan data permainan.

---

# ✨ Fitur Sistem

✅ Login

✅ Register

✅ Multiplayer Room

✅ Maksimal 2 Player

✅ Spectator Mode

✅ Real-Time Gameplay

✅ Sinkronisasi Posisi Pemain

✅ Best of 3 Round

✅ Server Side Score

✅ Leaderboard

✅ Statistik Pemain

✅ Penyimpanan Data ke Database

✅ Dashboard Statistik

---

# 🛠 Teknologi yang Digunakan

## Frontend

- HTML5
- CSS3
- JavaScript

## Backend

- Node.js
- Express.js

## Database

- MySQL

## Real-Time Communication

- WebSocket (ws)

## Server

- Laragon

---

# 📂 Struktur Project

```
dino-survival/
│
├── css/
├── js/
├── images/
├── screenshots/
├── database/
│   └── database.sql
│
├── server.js
├── package.json
├── index.html
├── README.md
└── ...
```

---

# ⚙️ Arsitektur Sistem

```
+-------------+
|   Client 1  |
+-------------+
        |
        |
        | WebSocket
        |
+----------------------+
|      Node Server     |
|  Express + WebSocket |
+----------------------+
        |
        |
        |
+----------------------+
|      MySQL           |
+----------------------+
        |
        |
+-------------+
|   Client 2  |
+-------------+
```

---

# 🗄 Database

## Tabel Users

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    wins INT DEFAULT 0,
    losses INT DEFAULT 0,
    points INT DEFAULT 0,
    matches INT DEFAULT 0
);
```

---

## Tabel Match Results

```sql
CREATE TABLE match_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    score INT,
    survive_time FLOAT,
    reaction_time FLOAT,
    round_number INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

# 🎮 Cara Bermain

1. Jalankan aplikasi.
2. Register akun baru.
3. Login menggunakan akun.
4. Pilih room yang tersedia.
5. Tunggu pemain kedua masuk.
6. Game akan dimulai otomatis.
7. Hindari obstacle menggunakan:
   - **SPACE** → Jump
   - **S** → Duck
8. Pemain dengan skor tertinggi memenangkan ronde.
9. Setelah maksimal 3 ronde, sistem menentukan pemenang pertandingan.

---

# 📊 Analisis Statistik

Sistem melakukan analisis terhadap data permainan yang tersimpan di database.

Statistik yang dihitung meliputi:

### 1. Rata-rata Skor

```sql
AVG(score)
```

---

### 2. Rata-rata Waktu Bertahan

```sql
AVG(survive_time)
```

---

### 3. Rata-rata Waktu Respon

```sql
AVG(reaction_time)
```

---

### 4. Konsistensi Pemain

```sql
MAX(score)-MIN(score)
```

---

### Analisis yang Dilakukan

Berdasarkan data hasil permainan, sistem dapat mengetahui:

- Apakah performa pemain meningkat.
- Apakah pemain semakin cepat merespon obstacle.
- Apakah pemain menjadi lebih konsisten.
- Apakah hipotesis pada proposal terbukti.

---

# 🖼 Screenshot Sistem

## Login

![Login](screenshots/login.png)

---

## Lobby

![Lobby](screenshots/lobby.png)

---

## Gameplay

![Gameplay](screenshots/gameplay.png)

---

## Leaderboard

![Leaderboard](screenshots/skor.png)

---

## Dashboard Statistik

![Statistik](screenshots/statistik.png)

---

# 🚀 Cara Menjalankan Project

## 1. Clone Repository

```bash
git clone https://github.com/username/dino-survival.git
```

---

## 2. Masuk Folder

```bash
cd dino-survival
```

---

## 3. Install Dependency

```bash
npm install
```

atau

```bash
npm install express ws uuid bcryptjs mysql2
```

---

## 4. Jalankan Laragon

Aktifkan:

- Apache
- MySQL

---

## 5. Import Database

Import file:

```
database.sql
```

ke phpMyAdmin.

---

## 6. Jalankan Server

```bash
node server.js
```

Jika berhasil akan muncul:

```
MySQL Connected

🦕 DINO SURVIVAL Server running on http://localhost:3000
```

---

## 7. Jalankan Game

Buka browser:

```
http://localhost/dino-survival
```

Apabila bermain pada dua komputer dalam satu jaringan:

```
http://IP_KOMPUTER_SERVER/dino-survival
```

Contoh:

```
http://192.168.1.11/dino-survival
```

---

# 📈 Hasil Analisis

Berdasarkan hasil pengujian yang telah dilakukan, diperoleh beberapa kesimpulan:

- Sistem multiplayer berjalan secara real-time.
- Sinkronisasi data antar pemain berjalan dengan baik.
- Data permainan berhasil disimpan ke database.
- Leaderboard berhasil menampilkan ranking pemain.
- Dashboard statistik berhasil menampilkan rata-rata skor, rata-rata waktu bertahan, rata-rata waktu respon, serta konsistensi pemain.
- Berdasarkan data yang diperoleh, terdapat indikasi peningkatan performa pemain setelah bermain beberapa kali.

---

# 📁 Link Penting

## Repository GitHub

https://github.com/mhmmdnabil/Tugas-Cloud-compoting

---

## Video Demo

https://github.com/mhmmdnabil/Tugas-Cloud-compoting

---

## Proposal PDF

https://github.com/mhmmdnabil/Tugas-Cloud-compoting

---

## Laporan Akhir PDF

https://github.com/mhmmdnabil/Tugas-Cloud-compoting

---

## Slide Presentasi PDF

https://github.com/mhmmdnabil/Tugas-Cloud-compoting

---

# 📄 Lisensi

Project ini dibuat hanya untuk keperluan akademik sebagai Final Project Mata Kuliah **Pemrograman WebSocket** Program Studi Teknik Informatika Universitas Islam Kalimantan Muhammad Arsyad Al Banjari.

---

# ⭐ Terima Kasih

Terima kasih kepada dosen pengampu serta seluruh anggota kelompok yang telah berkontribusi dalam pengembangan proyek **Dino Survival Multiplayer**.