// ============================================================
//  DINO SURVIVAL - WebSocket Game Server
//  Run: node server.js
//  Requires: npm install express ws uuid bcryptjs
// ============================================================

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const path = require('path');
const mysql = require('mysql2');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname)));
const dbMysql = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "dino_survival"
});

dbMysql.connect(err => {
  if (err) throw err;
  console.log("MySQL Connected");
});

// ─── In-Memory Database ───────────────────────────────────────
const db = {
  users: {},       // username -> { passwordHash, stats }
  sessions: {},    // token -> username
  rooms: {
    room1: createRoom('room1', 'Lava Canyon'),
    room2: createRoom('room2', 'Ice Tundra'),
    room3: createRoom('room3', 'Neon Desert'),
  }
};

function createRoom(id, name) {
  return {
    id, name,
    players: [],      // max 2, [{ws, username, score, alive}]
    spectators: [],   // [{ws, username}]
    gameState: null,
    round: 0,         // 1-3
    roundScores: {},  // username -> wins this match
    status: 'waiting' // waiting | playing | roundEnd | gameOver
  };
}

// ─── REST: Register ───────────────────────────────────────────
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password)
    return res.json({ ok: false, msg: 'Field kosong' });

  if (username.length < 3)
    return res.json({ ok: false, msg: 'Username min 3 karakter' });

  const hash = await bcrypt.hash(password, 10);

  dbMysql.query(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, hash],
    (err) => {
      if (err) return res.json({ ok: false, msg: 'Username sudah dipakai' });

      db.users[username] = {
        passwordHash: hash,
        stats: { wins: 0, losses: 0, points: 0, matches: 0 }
      };

      res.json({ ok: true, msg: 'Registrasi berhasil!' });
    }
  );
});

// ─── REST: Login ──────────────────────────────────────────────
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  dbMysql.query(
    "SELECT * FROM users WHERE username=?",
    [username],
    async (err, result) => {
      if (err) return res.json({ ok:false, msg:"Database error" });

      if (!result || result.length === 0)
        return res.json({ ok: false, msg: 'User tidak ditemukan' });

      const user = result[0];
      const valid = await bcrypt.compare(password, user.password);

      if (!valid)
        return res.json({ ok: false, msg: 'Password salah' });

      db.users[username] = {
        passwordHash: user.password,
        stats: {
          wins: user.wins,
          losses: user.losses,
          points: user.points,
          matches: user.matches
        }
      };

      const token = uuidv4();
      db.sessions[token] = username;

      res.json({ ok: true, token, username });
    }
  );
});

// ─── REST: Leaderboard ───────────────────────────────────────
app.get('/api/leaderboard', (req, res) => {
  dbMysql.query(
    "SELECT username, wins, losses, points, matches FROM users ORDER BY points DESC",
    (err, result) => {
      if (err) return res.json([]);

      const list = result.map(u => ({
        ...u,
        winRate: u.matches > 0
          ? Math.round((u.wins / u.matches) * 100)
          : 0
      }));

      res.json(list);
    }
  );
});

// ─── REST: Room List ─────────────────────────────────────────
app.get('/api/rooms', (req, res) => {
  const list = Object.values(db.rooms).map(r => ({
    id: r.id, name: r.name,
    players: r.players.length,
    spectators: r.spectators.length,
    status: r.status
  }));
  res.json(list);
});

app.get('/api/stats/:username', (req,res)=>{
  dbMysql.query(`
    SELECT
    AVG(score) AS avg_score,
    AVG(survive_time) AS avg_survive_time,
    AVG(reaction_time) AS avg_reaction_time,
    MAX(score)-MIN(score) AS consistency
    FROM match_results
    WHERE username=?
  `,[req.params.username],(err,result)=>{
    res.json(result[0]);
  });
});

// ─── WS Auth Helper ──────────────────────────────────────────
function authWS(token) {
  return db.sessions[token] || null;
}

// ─── WS Broadcast Helpers ────────────────────────────────────
function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function broadcastRoom(room, obj, exclude = null) {
  [...room.players, ...room.spectators].forEach(p => {
    if (p.ws !== exclude) send(p.ws, obj);
  });
}

function broadcastRoomInfo(room) {
  broadcastRoom(room, {
    type: 'ROOM_INFO',
    players: room.players.map(p => ({ username: p.username, score: p.score, alive: p.alive })),
    spectators: room.spectators.map(s => s.username),
    status: room.status,
    round: room.round,
    roundScores: room.roundScores
  });
}

function broadcastRooms() {
  const list = Object.values(db.rooms).map(r => ({
    id: r.id, name: r.name,
    players: r.players.length,
    spectators: r.spectators.length,
    status: r.status
  }));
  wss.clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN && ws._lobbyMode) send(ws, { type: 'ROOMS_UPDATE', rooms: list });
  });
}

// ─── Game Logic ──────────────────────────────────────────────
const GAME_WIDTH = 800;
const GAME_HEIGHT = 300;
const GROUND_Y = 260;
const GRAVITY = 0.6;
const JUMP_FORCE = -14;
const OBSTACLE_SPEED_BASE = 5;     // kecepatan awal
const SPEED_INCREMENT = 0.0025;    // laju kenaikan dasar (linear)
const SPEED_ACCEL = 0.0000012;     // faktor akselerasi (membuat makin lama makin cepat, bukan datar)
const MAX_SPEED = 18;               // batas kecepatan maksimal biar tetap fair/playable

function startRound(room) {
  room.status = 'playing';
  room.round++;

  const state = {
    tick: 0,
    speed: OBSTACLE_SPEED_BASE,
    obstacles: [],
    nextObstacle: 80,
    players: {}
  };

  room.players.forEach(p => {
    p.alive = true;
    p.score = 0;
    state.players[p.username] = {
      x: 80, y: GROUND_Y, vy: 0, onGround: true,
      ducking: false, alive: true, score: 0
    };
  });

  room.gameState = state;

  broadcastRoom(room, { type: 'ROUND_START', round: room.round });
  broadcastRoomInfo(room);

  room._interval = setInterval(() => gameTick(room), 1000 / 30);
}

function gameTick(room) {
  const s = room.gameState;
  if (!s) return;

  s.tick++;

  // Progresif: makin lama main, kenaikan kecepatan makin curam (akselerasi), bukan datar.
  // Math.pow(tick, 1.5) membuat kurva semakin menanjak seiring waktu, lalu dibatasi MAX_SPEED.
  const rawSpeed = OBSTACLE_SPEED_BASE
    + s.tick * SPEED_INCREMENT
    + Math.pow(s.tick, 1.5) * SPEED_ACCEL;
  s.speed = Math.min(MAX_SPEED, rawSpeed);

  // Move obstacles
  s.obstacles = s.obstacles.filter(o => o.x > -60);
  s.obstacles.forEach(o => { o.x -= s.speed; });

  // Spawn obstacles — jarak spawn ikut menyesuaikan kecepatan (semakin cepat, semakin rapat)
  s.nextObstacle--;
  if (s.nextObstacle <= 0) {
    const types = ['cactus_s', 'cactus_l', 'bird'];
    const t = types[Math.floor(Math.random() * types.length)];
    const yPos = t === 'bird' ? GROUND_Y - 60 - Math.floor(Math.random() * 40) : GROUND_Y;
    s.obstacles.push({ id: uuidv4().slice(0, 8), x: GAME_WIDTH + 20, y: yPos, type: t });

    const speedRatio = s.speed / OBSTACLE_SPEED_BASE; // makin tinggi speed, makin kecil jarak spawn
    const minGap = Math.max(22, Math.floor(45 / speedRatio));
    const maxGap = Math.max(minGap + 10, Math.floor(75 / speedRatio));
    s.nextObstacle = minGap + Math.floor(Math.random() * (maxGap - minGap));
  }

  // Update each player physics
  let aliveCount = 0;
  room.players.forEach(p => {
    if (!p.alive) return;
    const ps = s.players[p.username];
    if (!ps || !ps.alive) return;

    // Gravity
    ps.vy += GRAVITY;
    ps.y += ps.vy;
    if (ps.y >= GROUND_Y) { ps.y = GROUND_Y; ps.vy = 0; ps.onGround = true; }
    else { ps.onGround = false; }

    ps.score++;

    // Collision
    const pw = ps.ducking ? 44 : 40;
    const ph = ps.ducking ? 30 : 48;
    const px1 = ps.x + 8, py1 = ps.y - ph;
    const px2 = px1 + pw - 16, py2 = ps.y;

    for (const o of s.obstacles) {
      const ow = o.type === 'cactus_l' ? 30 : 24;
      const oh = o.type === 'bird' ? 24 : (o.type === 'cactus_l' ? 52 : 40);
      const ox1 = o.x, oy1 = o.y - oh;
      const ox2 = o.x + ow, oy2 = o.y;
      if (px1 < ox2 && px2 > ox1 && py1 < oy2 && py2 > oy1) {
        ps.alive = false;
        p.alive = false;
        p.score = ps.score;
        break;
      }
    }
    if (ps.alive) aliveCount++;
  });

  s.players && room.players.forEach(p => {
    const ps = s.players[p.username];
    if (ps) ps.score = p.score > ps.score ? p.score : ps.score;
  });

  // Broadcast game state
  broadcastRoom(room, {
    type: 'GAME_TICK',
    tick: s.tick,
    speed: s.speed,
    obstacles: s.obstacles,
    players: s.players
  });

  // Round ends when all die
  if (aliveCount === 0 || (room.players.length === 2 && aliveCount === 0)) {
    endRound(room);
  }
}

function endRound(room) {
  clearInterval(room._interval);
  room.status = 'roundEnd';

  // Determine round winner
  let winner = null;
  let maxScore = -1;
  room.players.forEach(p => {
    if (p.score > maxScore) { maxScore = p.score; winner = p.username; }
  });

  if (winner) {
    room.roundScores[winner] = (room.roundScores[winner] || 0) + 1;
  }
  room.players.forEach(p => {
  dbMysql.query(
    "INSERT INTO match_results(username, score, survive_time, reaction_time, round_number) VALUES (?, ?, ?, ?, ?)",
    [
      p.username,
      p.score,
      room.gameState.tick / 30,
      Math.random() * 0.5 + 0.2,
      room.round
    ]
  );
});

  broadcastRoom(room, {
    type: 'ROUND_END',
    round: room.round,
    winner,
    scores: room.players.map(p => ({ username: p.username, score: p.score })),
    roundScores: room.roundScores
  });

  // Check if match over (best of 3: 2 wins)
  const matchWinner = room.players.find(p => (room.roundScores[p.username] || 0) >= 2);
  if (matchWinner || room.round >= 3) {
    setTimeout(() => endMatch(room, matchWinner ? matchWinner.username : getBestPlayer(room)), 3000);
  } else {
    setTimeout(() => startRound(room), 4000);
  }
}

function getBestPlayer(room) {
  let best = null, max = -1;
  room.players.forEach(p => {
    const s = room.roundScores[p.username] || 0;
    if (s > max) { max = s; best = p.username; }
  });
  return best;
}

function endMatch(room, winner) {
  room.status = 'gameOver';

  // Update stats
  room.players.forEach(p => {
    const u = db.users[p.username];
    if (!u) return;
    u.stats.matches++;
    if (p.username === winner) {
      u.stats.wins++;
      u.stats.points += 2;
      dbMysql.query(
  "UPDATE users SET wins=wins+1, matches=matches+1, points=points+2 WHERE username=?",
  [p.username]
);
      
    } else {
      u.stats.losses++;
      u.stats.points = Math.max(0, u.stats.points - 1);
      dbMysql.query(
  "UPDATE users SET losses=losses+1, matches=matches+1, points=points-1 WHERE username=?",
  [p.username]
);
    }
  });

  broadcastRoom(room, {
    type: 'MATCH_OVER',
    winner,
    roundScores: room.roundScores,
    playerStats: room.players.map(p => {
      const u = db.users[p.username];
      return { username: p.username, stats: u ? u.stats : {} };
    })
  });

  // Reset room after 10s
  setTimeout(() => resetRoom(room), 10000);
}

function resetRoom(room) {
  room.status = 'waiting';
  room.round = 0;
  room.roundScores = {};
  room.gameState = null;
  room.players.forEach(p => { p.score = 0; p.alive = true; });
  broadcastRoom(room, { type: 'ROOM_RESET' });
  broadcastRoomInfo(room);
  broadcastRooms();
}

function removeFromRoom(ws, room) {
  const pi = room.players.findIndex(p => p.ws === ws);
  if (pi !== -1) {
    const p = room.players[pi];
    room.players.splice(pi, 1);
    broadcastRoom(room, { type: 'PLAYER_LEFT', username: p.username });
    if (room.status === 'playing' || room.status === 'roundEnd') {
      clearInterval(room._interval);
      room.status = 'waiting';
      room.round = 0;
      room.roundScores = {};
      broadcastRoom(room, { type: 'GAME_ABORTED', msg: 'Pemain keluar, permainan dibatalkan.' });
    }
    broadcastRoomInfo(room);
    broadcastRooms();
    return true;
  }
  const si = room.spectators.findIndex(s => s.ws === ws);
  if (si !== -1) {
    const s = room.spectators[si];
    room.spectators.splice(si, 1);
    broadcastRoom(room, { type: 'SPECTATOR_LEFT', username: s.username });
    broadcastRoomInfo(room);
    return true;
  }
  return false;
}

// ─── WebSocket Handler ───────────────────────────────────────
wss.on('connection', (ws) => {
  ws._room = null;
  ws._username = null;
  ws._lobbyMode = false;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    const { type } = msg;

    // ── Auth ──
    if (type === 'AUTH') {
      const username = authWS(msg.token);
      if (!username) return send(ws, { type: 'AUTH_FAIL' });
      ws._username = username;
      ws._lobbyMode = true;
      send(ws, { type: 'AUTH_OK', username });
      const stats = db.users[username]?.stats;
      const winRate = stats && stats.matches > 0 ? Math.round((stats.wins / stats.matches) * 100) : 0;
      send(ws, { type: 'STATS', stats: { ...stats, winRate } });
      return;
    }

    if (!ws._username) return send(ws, { type: 'ERROR', msg: 'Belum auth' });

    // ── Lobby Mode ──
    if (type === 'GET_ROOMS') {
      ws._lobbyMode = true;
      const list = Object.values(db.rooms).map(r => ({
        id: r.id, name: r.name,
        players: r.players.length, spectators: r.spectators.length, status: r.status
      }));
      send(ws, { type: 'ROOMS_UPDATE', rooms: list });
      return;
    }

    // ── Join Room ──
    if (type === 'JOIN_ROOM') {
      const { roomId, role } = msg;
      const room = db.rooms[roomId];
      if (!room) return send(ws, { type: 'ERROR', msg: 'Room tidak ditemukan' });

      // Remove from previous room
      if (ws._room) removeFromRoom(ws, ws._room);
      ws._lobbyMode = false;
      ws._room = room;

      if (role === 'player') {
        if (room.players.length >= 2) {
          ws._room = null;
          return send(ws, { type: 'JOIN_DENIED', msg: 'Maaf Pemain Sudah mencapai batas maksimal, silahkan menunggu permainan selesai diruang penonton / cari room yang kosong.' });
        }
        room.players.push({ ws, username: ws._username, score: 0, alive: true });
        send(ws, { type: 'JOIN_OK', role: 'player', roomId, roomName: room.name });
        broadcastRoom(room, { type: 'PLAYER_JOINED', username: ws._username });
        broadcastRoomInfo(room);
        broadcastRooms();

        // Auto-start if 2 players
        if (room.players.length === 2 && room.status === 'waiting') {
          room.roundScores = {};
          setTimeout(() => startRound(room), 2000);
        }
      } else {
        room.spectators.push({ ws, username: ws._username });
        send(ws, { type: 'JOIN_OK', role: 'spectator', roomId, roomName: room.name });
        broadcastRoom(room, { type: 'SPECTATOR_JOINED', username: ws._username });
        broadcastRoomInfo(room);
      }
      return;
    }

    // ── Leave Room ──
    if (type === 'LEAVE_ROOM') {
      if (ws._room) { removeFromRoom(ws, ws._room); ws._room = null; }
      ws._lobbyMode = true;
      send(ws, { type: 'LEFT_ROOM' });
      return;
    }

    // ── Player Input ──
    if (type === 'PLAYER_INPUT') {
      const room = ws._room;
      if (!room || !room.gameState) return;
      const ps = room.gameState.players[ws._username];
      if (!ps || !ps.alive) return;
      if (msg.action === 'jump' && ps.onGround) {
        ps.vy = JUMP_FORCE;
        ps.onGround = false;
      }
      if (msg.action === 'duck_start') ps.ducking = true;
      if (msg.action === 'duck_end') ps.ducking = false;
      return;
    }

    // ── Chat (spectators only) ──
    if (type === 'CHAT') {
      const room = ws._room;
      if (!room) return;
      const isSpectator = room.spectators.some(s => s.ws === ws);
      if (!isSpectator) return;
      const text = (msg.text || '').slice(0, 200);
      broadcastRoom(room, { type: 'CHAT', username: ws._username, text, timestamp: Date.now() });
      return;
    }

    // ── Emote ──
    if (type === 'EMOTE') {
      const room = ws._room;
      if (!room) return;
      const isSpectator = room.spectators.some(s => s.ws === ws);
      if (!isSpectator) return;
      broadcastRoom(room, { type: 'EMOTE', username: ws._username, emote: msg.emote });
      return;
    }

    // ── Voice Signal (WebRTC signaling) ──
    if (type === 'VOICE_SIGNAL') {
      const room = ws._room;
      if (!room) return;
      const { to, signal } = msg;
      const target = [...room.players, ...room.spectators].find(p => p.username === to);
      if (target) send(target.ws, { type: 'VOICE_SIGNAL', from: ws._username, signal });
      return;
    }
  });

  ws.on('close', () => {
    if (ws._room) removeFromRoom(ws, ws._room);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🦕 DINO SURVIVAL Server running on http://localhost:${PORT}`);
  console.log(`📦 Make sure to run: npm install express ws uuid bcryptjs\n`);
});
